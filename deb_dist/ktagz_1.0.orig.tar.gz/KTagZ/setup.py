from distutils.core import setup

setup(
	name = "ktagz",
	packages = ["ktagzpackage"],
	version = "1.0",
	description = "A command line file-tagger/file-search tool for linux",
	long_description = open('README.md').read(),
	author = "Khirod Kant Naik (Undergrad from IIITA)",
	author_email = "khirod234@gmail.com",
	url='https://github.com/shinigamiryuk/TagZ',
	scripts = ['bin/ktagz'],
)
